<?php
    $con = mysqli_connect("localhost", "root", "", "covid_survey");
?>