<?php
    include '../koneksi/koneksi.php';
    if(isset($_POST['simpan'])){
        $sql = mysqli_query($con, "INSERT INTO tb_keterangan VALUES('', '$_POST[keterangan]')");
        if($sql){
            echo "<script>alert('Berhasil');</script>";
        }else{
            echo "<script>alert('Gagal');</script>";
        }
    }
    if(isset($_GET['hapus'])){
        $sql = mysqli_query($con, "DELETE FROM tb_keterangan WHERE id = '$_GET[id]'");   
        if($sql){
            echo "<script>alert('berhasil');</script>";
        }else{
            echo "<script>alert('gagal');</script>";
        }
    }
?>
<html>
    <head>
        
    </head>
    <form method="post">
        <body>
            <table>
                <tr>
                    <td><input type="text" name="keterangan" required=""></td>
                </tr>
                <tr>
                    <td><input type="submit" name="simpan" value="SIMPAN"></td>
                </tr>
            </tablel>
            <table border="1">
                <tr>
                    <th>No</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
                <tr>
                    <?php
                        $no = 0;
                        $sql = mysqli_query($con, "SELECT * FROM tb_keterangan");
                        while($r = mysqli_fetch_array($sql)){
                            $no++; ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $r['keterangan']; ?></td>
                            <td><a href="?admin=admin&hapus&id=<?php echo $r['id'] ?>" onClick="return confirm('Anda Yakin?')">Hapus</a></td>
                        </tr>
                    <?php } ?>
                </tr>
            </table>
        </body>
    </form>
</html>