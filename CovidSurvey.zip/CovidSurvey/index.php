<?php
    include 'naon/koneksi/koneksi.php';
    if(isset($_POST['cek'])){
        if($_POST['total'] <= 7){
            $resiko = "Resiko Rendah";
        }elseif($_POST['total'] <= 14){
            $resiko = "Resiko Sedang";
        }else{
            $resiko = "Resiko Tinggi";
        }
        $sql = mysqli_query($con, "INSERT INTO tb_data VALUES('', '$_POST[nama]', '$_POST[jk]', '$_POST[umur]', '$_POST[alamat]', '$_POST[total]')");
        if($sql){
            echo "<script>alert('Terima kasih banyak $_POST[nama], resiko anda terkena Virus COVID-19 adalah $resiko');</script>";
        }else{
            echo "<script>alert('Gagal');</script>";
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>COVID-19 | Hanafi Abdilah</title>
        <link rel="shortcut icon" href="img/icon.ico">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="style/style.css">
    </head>
    <form method="post" action="" id="theForm">
    <body style="background-color: #3BA7D6">
        <div class="container">
            <div class="card bg-info shadow mb-4" style="margin-top: 20px;">
                <div class="card-body">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control" required="">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Jenis Kelamin</label>
                            <select class="form-control" name="jk" required="">
                                <option value="" disabled selected>Pilih Jenis Kelamin</option>
                                <option value="l">Laki Laki</option>
                                <option value="p">Perempuan</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Umur</label>
                            <input type="number" name="umur" class="form-control" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea type="text" name="alamat" class="form-control"></textarea>
                    </div>
                    <br>
                    <h3 align="center">DAFTAR PERTANYAAN PENILAIAN RESIKO PRIBADI TERKAIT COVID 19</h3>
                    <table class="table table-info">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>KETERANGAN</th>
                                <th>CENTANG JIKA BENAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $no = 0;
                                $sql = mysqli_query($con, "SELECT * FROM tb_keterangan");
                                while($r = mysqli_fetch_array($sql)){
                                    $no++; ?>
                                <tr>
                                    <td><?php echo $no ?></td>
                                    <td><label><?php echo $r['keterangan']; ?></label></td>
                                    <td align="center">
                                        <input value="1" type="checkbox" name="ya" onClick="totalIt()">
                                    </td>
                                </tr>
                            <?php } ?>  
                        </tbody>
                    </table>
                    <button name="cek" class="btn btn-warning shadow">CEK</button>
                    <input type="hidden" id="total" name="total"/>
                    <br><br>
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> This website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/hanafabdilah" target="_blank">Hanafi Abdilah</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </form>
    <script>
        function totalIt() {
        var input = document.getElementsByName("ya");
        var total = 0;
        for (var i = 0; i < input.length; i++) {
            if (input[i].checked) {
            total += parseFloat(input[i].value);
            }
        }
        document.getElementById("total").value = total;
        }
    </script>
</html>